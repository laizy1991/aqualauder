/*! TenVideoPlayer_V2 - v2.0.0 - 2015-09-18 18:06:51
* Copyright (c) 2015
* Powered by Tencent-Video Web Front End Team
*/
window.tvp||(tvp={}),tvp.config={defaultConfig:{caseSetting:{case3:{}}},authRules:[{reg:function(){return location.hostname.indexOf("caixin.com")>-1?!0:!1},request:function(a){var b=this,c={cgi:b.cfg2.cgi.getinfo,param:{platform:"961001",sdtfrom:"v1093",vids:b.cfg.vid,defaultfmt:b.cfg.fmt}};a.resolve(c)}}]};
